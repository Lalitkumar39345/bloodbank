<?php
error_reporting(0);
include ('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BloodBank System</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
        .navbar-toggler {
            z-index: 1;
        }

        @media (max-width: 576px) {
            nav>.container {
                width: 100%;
            }
        }

        .carousel-item.active,
        .carousel-item-next,
        .carousel-item-prev {
            display: block;
        }
    </style>

</head>

<body>

    <!-- Navigation -->
    <?php include ('includes/header.php'); ?>
    <?php include ('includes/slider.php'); ?>

    <!-- Page Content -->
    <div class="container">

        <h1 class="my-4">Welcome to BloodBank & Donor Management System</h1>

        <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12 mb-4">
                <div class="card">
                    <h4 class="card-header">The need for blood</h4>

                    <p class="card-text" style="padding-left:3%">Blood is a lifeline for countless individuals facing
                        critical medical conditions, emergencies, and surgical procedures. Despite advancements in
                        medical science, there is no substitute for human blood. Hence, the constant need for blood
                        donations persists, underscoring the crucial role of blood banks in healthcare systems
                        worldwide.
                    <h5>Medical Emergencies:</h5>
                    <p>In medical emergencies such as accidents, natural disasters, or childbirth complications, the
                        need for blood is immediate and often lifesaving. A steady supply of various blood types is
                        essential to meet the unpredictable demands arising from such emergencies.</p>
                    <h5>Chronic Conditions:</h5>
                    <p>Beyond emergencies, individuals battling chronic diseases like cancer, anemia, or hemophilia
                        require regular blood transfusions to manage their conditions. For them, blood donations are not
                        just life-supporting but life-sustaining.</p>
                    <h5>Specialized Needs:</h5>
                    <p>Certain medical conditions necessitate specific blood components, such as platelets or plasma,
                        which have shorter shelf lives compared to whole blood. Maintaining a diverse inventory of blood
                        products is imperative to cater to the diverse needs of patients.</p>

                    </p>

                </div>
            </div>
            <div class="col-lg-12 mb-4">
                <div class="card">
                    <h4 class="card-header">Blood Tips</h4>

                    <p class="card-text" style="padding-left:3%">Understanding your blood type is crucial for both
                        donors and recipients. Knowing your blood type helps ensure compatibility during transfusions
                        and allows blood banks to allocate resources efficiently.
                    <h5>Regular Health Checkups:</h5>
                    <p>Before donating blood, ensure you're in good health. Regular health checkups help identify any
                        underlying conditions that may affect your eligibility to donate. It's essential to disclose any
                        relevant medical history to ensure the safety of both donors and recipients.</p>
                    <h5>Stay Hydrated:</h5>
                    <p>Hydration is key to a successful blood donation. Drink plenty of fluids, especially water, in the
                        days leading up to your donation. Proper hydration helps maintain blood volume and reduces the
                        risk of complications during and after donation.</p>
                    <h5> Be Prepared for Emergencies:</h5>
                    <p>In case of emergencies or unforeseen medical needs, knowing where your nearest blood bank is
                        located can be invaluable. Familiarize yourself with the procedures for accessing blood services
                        in your area to ensure prompt response when needed.</p>

                    </p>

                </div>
            </div>
            <div class="col-lg-12 mb-4">
                <div class="card">
                    <h4 class="card-header">Who you could Help</h4>

                    <p class="card-text" style="padding-left:3%">Every drop of blood you donate has the power to save
                        lives and make a significant impact on individuals in need. At GLOBAL BLAD BANK FOR EVERY ONE,
                        we believe in the transformative potential of blood donation, reaching out to diverse
                        individuals and communities with compassion and support.
                    <h5>Patients in Medical Emergencies:</h5>
                    <p>Your blood donation can be a lifeline for those facing critical medical emergencies such as
                        accidents, traumas, or complications during childbirth. In these dire situations, timely access
                        to compatible blood can mean the difference between life and death. Your generosity can provide
                        hope and healing to those in urgent need.</p>
                    <h5>Individuals Battling Chronic Illnesses:</h5>
                    <p>Many individuals, young and old, are engaged in a relentless battle against chronic illnesses
                        such as cancer, thalassemia, or sickle cell disease. Regular blood transfusions are often a
                        vital component of their treatment plans, helping to alleviate symptoms and improve their
                        quality of life. Your blood donation can offer them the strength to continue their fight with
                        resilience and determination.</p>
                    <h5>New Mothers and Babies:</h5>
                    <p>Childbirth can sometimes lead to unforeseen complications, putting both the mother and baby at
                        risk. In such situations, blood transfusions may be necessary to address maternal hemorrhage or
                        complications in newborns. Your blood donation could ensure the safety and well-being of mothers
                        and infants, ushering in the joy of new life amidst challenging circumstances.</p>
                    </p>
                </div>
            </div>
        </div>
        <!-- /.row -->

        <!-- Portfolio Section -->
        <h2>Some of the Donar</h2>

        <div class="row">
            <?php
            $status = 1;
            $sql = "SELECT * from tblblooddonars where status=:status order by rand() limit 6";
            $query = $dbh->prepare($sql);
            $query->bindParam(':status', $status, PDO::PARAM_STR);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);
            $cnt = 1;
            if ($query->rowCount() > 0) {
                foreach ($results as $result) { ?>

                    <div class="col-lg-4 col-sm-6 portfolio-item">
                        <div class="card h-100">
                            <a href="#"><img class="card-img-top img-fluid" src="images/blood-donor.jpg" alt=""></a>
                            <div class="card-block">
                                <h4 class="card-title"><a href="#">
                                        <?php echo htmlentities($result->FullName); ?>
                                    </a></h4>
                                <p class="card-text"><b> Gender :</b>
                                    <?php echo htmlentities($result->Gender); ?>
                                </p>
                                <p class="card-text"><b>Blood Group :</b>
                                    <?php echo htmlentities($result->BloodGroup); ?>
                                </p>

                            </div>
                        </div>
                    </div>

                <?php }
            } ?>





        </div>
        <!-- /.row -->

        <!-- Features Section -->
        <div class="row">
            <div class="col-lg-6">
                <h2>BLOOD GROUPS</h2>
                <p> blood group of any human being will mainly fall in any one of the following groups.</p>
                <ul>
                    <li>A positive or A negative</li>
                    <li>B positive or B negative</li>
                    <li>O positive or O negative</li>
                    <li>AB positive or AB negative.</li>
                </ul>
                <p>A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out
                    the following recommended foods to eat prior to your donation.</p>
            </div>
            <div class="col-lg-6">
                <img class="img-fluid rounded" src="images/blood-donor (1).jpg" alt="">
            </div>
        </div>
        <!-- /.row -->

        <hr>

        <!-- Call to Action Section -->
        <div class="row mb-4">
            <div class="col-md-8">
                <h4>UNIVERSAL DONORS AND RECIPIENTS</h4>
                <p>
                    The most common blood type is O, followed by type A.

                    Type O individuals are often called "universal donors" since their blood can be transfused into
                    persons with any blood type. Those with type AB blood are called "universal recipients" because they
                    can receive blood of any type.</p>
            </div>
            <div class="col-md-4">
    <a class="btn btn-lg btn-primary btn-block" id="donarBtn" href="become-donar.php">Become a Donar</a>
</div>
        </div>

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <?php include ('includes/footer.php'); ?>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>